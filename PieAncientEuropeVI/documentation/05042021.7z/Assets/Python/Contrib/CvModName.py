#CvModName.py

modName = "K-Mod"
displayName = "K-Mod"
modVersion = ""

civName = "BtS"
civVersion = "3.19"

def getName():
	return modName

def getDisplayName():
	return displayName

def getVersion():
	return modVersion

def getNameAndVersion():
	return modName + " " + modVersion

def getDisplayNameAndVersion():
	return displayName + " " + modVersion


def getCivName():
	return civName

def getCivVersion():
	return civVersion

def getCivNameAndVersion():
	return civName + " " + civVersion
