## PlotListEnhancements
##
## Utility functions for PLE by EmperorFool

def resetUnitPlotListStackedBarColors(option, value):
	import CvScreensInterface
	CvScreensInterface.mainInterface.resetUnitPlotListStackedBarColors()
